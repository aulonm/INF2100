INF2100
=======
Contributors:

	*	Aulon Mujaj
		* Bruker: aulonm
		* Mail: aulon@mujaj.no
	*	Halvor Mangseth
		*Bruker: halvorhm


INF2100 School Project - AlboC Compiler

